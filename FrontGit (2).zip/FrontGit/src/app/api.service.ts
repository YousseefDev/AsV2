import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private baseUrl = 'http://localhost:8070/api/v1';

  constructor(private http: HttpClient, private authService: AuthService) {}

  private getHeaders(): HttpHeaders {
    const accessToken = this.authService.getCurrentUser();

    // Set the Authorization header with the access token
    return new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${accessToken}`
    });
  }

  login(email: string, password: string): Observable<any> {
    const loginData = { email, password };
    return this.http.post<any>(`${this.baseUrl}/auth/login`, loginData);
  }

  createLeaveRequest(leaveRequestData: any): Observable<any> {
    const headers = this.getHeaders();
    return this.http.post<any>(`${this.baseUrl}/requests/leave/send-req`, leaveRequestData, { headers });
  }
  createLoanRequest(requestData: any): Observable<any> {
    const headers = this.getHeaders();
    return this.http.post<any>(`${this.baseUrl}/requests/loan/send-req`, requestData, { headers });
  }
  createDocumentRequest(requestData: any): Observable<any> {
    const headers = this.getHeaders();
    return this.http.post<any>(`${this.baseUrl}/requests/document/send-req`, requestData, { headers });
  }

  createAuthRequest(requestData: any): Observable<any> {
    const headers = this.getHeaders();
    return this.http.post<any>(`${this.baseUrl}/requests/auth/send-req`, requestData, { headers });
  }
  createPersonalSituationRequest(requestData: any): Observable<any> {
    const headers = this.getHeaders();
    return this.http.post<any>(`${this.baseUrl}/requests/personal/send-req`, requestData, { headers });
  }
  getMyRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/my-requests`, { headers });
  }

  getAllRequestsHR(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/Hr_req`, { headers });
  }

  getPendingRequestsHR(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/RH-pending-requests`, { headers });
  }

  // New methods for Admin requests
  getAdminRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/Admin_req`, { headers });
  }

  getAdminPendingRequests(): Observable<any[]> {
    const headers = this.getHeaders();
    return this.http.get<any[]>(`${this.baseUrl}/requests/Admin-pending-requests`, { headers });
  }

  updateRequestStatus(requestId: number, newStatus: string): Observable<any> {
    const headers = this.getHeaders();
    const params = { newstatus: newStatus };
    return this.http.put<any>(`${this.baseUrl}/requests/${requestId}/status`, null, { headers, params });
  }

  getUserProfile(): Observable<any> {
    const headers = this.getHeaders();
    return this.http.get<any>(`${this.baseUrl}/users/profile`, { headers });
  }
}
