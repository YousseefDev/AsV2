import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-dashboard',
  templateUrl: './employee-dashboard.component.html',
  styleUrls: ['./employee-dashboard.component.scss']
})
export class EmployeeDashboardComponent implements OnInit {
  requestTypes: string[] = ['Auth', 'Leave', 'Loan', 'Document', 'Personal-situation'];
  selectedRequestType: string = '';
  showLeave = false;
  showLoan = false;
  showAuthorization = false;
  showDocument = false;
  showpersonalSituation = false;

  constructor(private apiService: ApiService, private authService: AuthService ,private router: Router) {}

  ngOnInit(): void {}

  showLeaveRequest(): void {
    this.resetRequestTypes();
    this.showLeave = true;
  }

  showLoanRequest(): void {
    this.resetRequestTypes();
    this.showLoan = true;
  }

  showAuthorizationRequest(): void {
    this.resetRequestTypes();
    this.showAuthorization = true;
  }

  showDocumentRequest(): void {
    this.resetRequestTypes();
    this.showDocument = true;
  }

  showpersonalSituationRequest(): void {
    this.resetRequestTypes();
    this.showpersonalSituation = true;
  }

  resetRequestTypes(): void {
    this.showLeave = false;
    this.showLoan = false;
    this.showAuthorization = false;
    this.showDocument = false;
    this.showpersonalSituation = false;
  }
  navigateToProfile(): void {
    this.router.navigate(['/profile']);
  }
}
