import { Component } from '@angular/core';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-document-request',
  templateUrl: './document-request.component.html',
  styleUrls: ['./document-request.component.scss']
})
export class DocumentRequestComponent {
  documentRequest: any = {
    documentType: '',
    reason: ''
  };

  constructor(private apiService: ApiService, private router: Router) {}

  submitDocumentRequest(): void {
    this.apiService.createDocumentRequest(this.documentRequest).subscribe(
      (response) => {
        console.log('Document request created successfully:', response);
        this.router.navigate(['/employee']);
      },
      (error) => {
        console.error('Error creating document request:', error);
        // Handle error (e.g., display error message to user)
      }
    );
  }
}
