import { Component } from '@angular/core';
import { ApiService } from '../../api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-loan-request',
  templateUrl: './loan-request.component.html',
  styleUrls: ['./loan-request.component.scss']
})
export class LoanRequestComponent {
  loanRequest: any = {
    title: '',
    description: '',
    amount: null,
    purpose: '',
    repaymentPlan: '',
    loanType: '',
    additionalNotes: ''
  };

  constructor(private apiService: ApiService, private router: Router) {}

  submitLoanRequest(): void {
    console.log('Loan Request Data:', this.loanRequest);
    this.apiService.createLoanRequest(this.loanRequest).subscribe(
      (response) => {
        console.log('Loan request created successfully:', response);
        this.router.navigate(['/employee']);
      },
      (error) => {
        console.error('Error creating loan request:', error);
        // Handle error (e.g., display error message to user)
      }
    );
  }
}
