package com.example.version1.requests.Leave;



import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
@Entity
@Table(name = "leave_requests")
@Getter
@Setter
public class LeaveRequest {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "user_id")
    private Long userId;    // Specific fields for LeaveRequest
    private String leaveReason;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private String documentUrl;

    @Column(name = "status", columnDefinition = "VARCHAR(255) DEFAULT 'pending'") // Set default status to 'pending'
    private String status;
    // Include other common fields if needed
}
