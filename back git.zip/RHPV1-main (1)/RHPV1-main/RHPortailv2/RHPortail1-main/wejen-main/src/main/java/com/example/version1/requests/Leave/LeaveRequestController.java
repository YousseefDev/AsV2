package com.example.version1.requests.Leave;

import com.example.version1.requests.Leave.LeaveRequest;
import com.example.version1.requests.Leave.LeaveRequestService;
import com.example.version1.users.User;
import com.example.version1.users.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;
import com.example.version1.users.User;


import javax.naming.AuthenticationException;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/requests/leave")
public class LeaveRequestController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private LeaveRequestService leaveRequestService;

    @PostMapping("/send-req")
    public ResponseEntity<LeaveRequest> createLeaveRequest(@RequestBody LeaveRequest request,
                                                           Authentication authentication) throws AuthenticationException {
        if (authentication == null || !authentication.isAuthenticated() || !(authentication.getPrincipal() instanceof Jwt)) {
            throw new AuthenticationException("Authentication is missing or invalid for this request");
        }

        Jwt jwtToken = (Jwt) authentication.getPrincipal();
        String userEmail = jwtToken.getClaim("sub");

        Optional<User> userOptional = userRepository.findByEmail(userEmail);
        if (userOptional.isEmpty()) {
            throw new AuthenticationException("User not found");
        }
        User user = userOptional.get();
        Long userId = user.getId();

        request.setUserId(userId);

        // Set default status to 'pending' if status is not provided
        if (request.getStatus() == null || request.getStatus().isEmpty()) {
            request.setStatus("pending");
        }

        LeaveRequest createdRequest = leaveRequestService.createLeaveRequest(request,userId);
        return new ResponseEntity<>(createdRequest, HttpStatus.CREATED);
    }
}
