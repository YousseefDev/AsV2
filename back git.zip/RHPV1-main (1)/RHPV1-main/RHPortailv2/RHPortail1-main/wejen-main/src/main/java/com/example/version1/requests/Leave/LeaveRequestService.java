package com.example.version1.requests.Leave;

import com.example.version1.requests.Leave.LeaveRequest;
import com.example.version1.requests.Leave.LeaveRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LeaveRequestService {

    @Autowired
    private LeaveRequestRepository leaveRequestRepository;

    public LeaveRequest createLeaveRequest(LeaveRequest request , Long userId) {
        return leaveRequestRepository.save(request);
    }
}
