    package com.example.version1.requests;

    import com.example.version1.requests.DTO.LeaveRequestDTO;
    import com.example.version1.requests.Leave.LeaveRequest;
    import com.example.version1.requests.Leave.LeaveRequestRepository;
    import com.example.version1.requests.auth.AuthRequest;
    import com.example.version1.requests.auth.AuthRequestRepository;
    import com.example.version1.requests.document.DocumentRequest;
    import com.example.version1.requests.document.DocumentRequestRepository;
    import com.example.version1.requests.loan.LoanRequest;
    import com.example.version1.requests.loan.LoanRequestRepository;
    import com.example.version1.requests.personal.PersonalSituationRequest;
    import com.example.version1.requests.personal.PersonalSituationRequestRepository;
    import lombok.RequiredArgsConstructor;
    import org.springframework.stereotype.Service;

    import java.util.ArrayList;
    import java.util.List;
    import java.util.stream.Collectors;

    @Service
    @RequiredArgsConstructor
    public class RequestService {
        private final RequestRepository requestRepository;

        private final LeaveRequestRepository leaveRequestRepository;
        private final LoanRequestRepository loanRequestRepository;
        private final PersonalSituationRequestRepository personalSituationRequestRepository;
        private final DocumentRequestRepository documentRequestRepository;
        private final AuthRequestRepository authRequestRepository;
  public List<Request> getRequestsByUserId(Long userId) {
    // Retrieve requests from different tables
    List<Request> allRequests = new ArrayList<>();

    // Add requests from the main request table
    allRequests.addAll(requestRepository.findByUserId(userId));

    List<Request> leaveRequests =
        (List<Request>) (List<?>) leaveRequestRepository.findByUserId(userId);
    allRequests.addAll(leaveRequests);

    List<Request> loanRequests =
        (List<Request>) (List<?>) loanRequestRepository.findByUserId(userId);
    allRequests.addAll(loanRequests);

      List<Request> personalRequests =
              (List<Request>) (List<?>) personalSituationRequestRepository.findByUserId(userId);
      allRequests.addAll(personalRequests);

      List<Request> DocumentRequests =
              (List<Request>) (List<?>) documentRequestRepository.findByUserId(userId);
      allRequests.addAll(DocumentRequests);

      List<Request> AuthRequests =
              (List<Request>) (List<?>) authRequestRepository.findByUserId(userId);
      allRequests.addAll(AuthRequests);






      return allRequests;

  }




            public List<Request> getAllRequest() {
            return requestRepository.findAll();
        }

        public List<Request> getRequestsByTypes(List<String> allowedTypes) {
            return requestRepository.findAll().stream()
                    .filter(request -> allowedTypes.contains(request.getTypeRequest()))
                    .collect(Collectors.toList());
        }



        public Request createRequest(Request request, Long userId) {  // Add userId as a method parameter
            request.setStatus("Pending");
            request.setUserId(userId);
            return requestRepository.save(request);
        }

        public Request getRequestById(Long id) {
            return requestRepository.findById(id)
                    .orElseThrow(() -> new RuntimeException("Request not found."));
        }

        public Request updateRequest(Long id, Request updatedRequest) {
            Request request = getRequestById(id);
            request.setTitle(updatedRequest.getTitle());
            request.setDescription(updatedRequest.getDescription());
            return requestRepository.save(request);
        }

        public Request updateRequeststatus(Long requestId, String newstatus) {
            Request request = requestRepository.findById(requestId)
                    .orElseThrow(() -> new RuntimeException("Request not found with ID: " + requestId));

            request.setStatus(newstatus);
            return requestRepository.save(request);
        }


    }
