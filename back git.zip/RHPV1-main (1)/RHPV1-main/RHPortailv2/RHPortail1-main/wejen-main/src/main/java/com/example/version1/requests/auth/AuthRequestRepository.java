// AuthRequestRepository.java
package com.example.version1.requests.auth;

import com.example.version1.requests.Request;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AuthRequestRepository extends JpaRepository<AuthRequest, Long> {
    List<AuthRequest> findByUserId(Long userId);

}
