// AuthRequestService.java
package com.example.version1.requests.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthRequestService {

    @Autowired
    private AuthRequestRepository authRequestRepository;

    public AuthRequest createAuthRequest(AuthRequest request, Long userId) {
        request.setUserId(userId);
        return authRequestRepository.save(request);
    }
}
