package com.example.version1.requests.document;

import com.example.version1.requests.document.DocumentRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DocumentRequestService {

    private final DocumentRequestRepository documentRequestRepository;

    @Autowired
    public DocumentRequestService(DocumentRequestRepository documentRequestRepository) {
        this.documentRequestRepository = documentRequestRepository;
    }

    public DocumentRequest createDocumentRequest(DocumentRequest documentRequest, Long userId) {
        // Set user ID on the document request before saving
        documentRequest.setUserId(userId);
        return documentRequestRepository.save(documentRequest);
    }
}
