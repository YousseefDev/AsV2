package com.example.version1.requests.personal;

import com.example.version1.requests.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersonalSituationRequestService {

    @Autowired
    private PersonalSituationRequestRepository personalSituationRequestRepository;

    public PersonalSituationRequest createPersonalSituationRequest(PersonalSituationRequest request, Long userId) {
       return personalSituationRequestRepository.save(request);
    }

}
